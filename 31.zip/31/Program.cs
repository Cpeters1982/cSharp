﻿using System;

namespace thirtyone
{
    class Program
    {
        public static void Main(string[] args)
        {
            Game myGame = new Game();
            myGame.game();
        }
    }
}
