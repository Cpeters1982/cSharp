using System;

namespace thirtyone
{
    public class Card{
        public string stringVal;
        public string suit;
        public int val;
    }
}