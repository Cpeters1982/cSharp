using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace demo.Controllers
{
    public class democontroller : Controller
    {
        // [HttpGet]
        // [Route("/{Name}")]
        // public IActionResult Method(string Name)
        // {
        //     // Method body
        //     // return $"hello {Name}"
        // }



        [HttpGet]
        [Route("{FirstName}/{LastName}/{Age}/{FavColor}")]
        public JsonResult JSON(string FirstName, string LastName, int Age, string FavColor)
        {
            return Json(new {FirstName, LastName, Age, FavColor});
        }
    }
}